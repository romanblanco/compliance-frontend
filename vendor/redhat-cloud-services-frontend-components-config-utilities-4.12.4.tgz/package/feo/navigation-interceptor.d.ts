import { DirectNavItem, FrontendCRD, Nav } from './feo-types';
declare const substituteLocalNav: (frontendCRD: FrontendCRD, nav: Nav, bundleName: string) => DirectNavItem[];
export default substituteLocalNav;
