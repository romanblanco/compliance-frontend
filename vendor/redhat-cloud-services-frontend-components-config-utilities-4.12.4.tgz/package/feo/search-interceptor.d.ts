import { ChromeStaticSearchEntry, FrontendCRD } from './feo-types';
declare function searchInterceptor(staticSearchIndex: ChromeStaticSearchEntry[], frontendCRD: FrontendCRD): ChromeStaticSearchEntry[];
export default searchInterceptor;
