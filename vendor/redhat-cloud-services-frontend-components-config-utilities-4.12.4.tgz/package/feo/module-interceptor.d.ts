import { ChromeModuleRegistry, FrontendCRD } from './feo-types';
declare function moduleInterceptor(moduleRegistry: ChromeModuleRegistry, frontendCRD: FrontendCRD): ChromeModuleRegistry;
export default moduleInterceptor;
