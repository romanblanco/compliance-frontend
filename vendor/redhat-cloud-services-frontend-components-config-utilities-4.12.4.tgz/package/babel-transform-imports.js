"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
var glob = __importStar(require("glob"));
var defaultRoot = process.cwd();
var PROPS_MATCH = /Props$/g;
var VARIANT_MATCH = /Variants?$/g;
var POSITION_MATCH = /Position$/g;
var iconMapper = {
    AnsibeTowerIcon: 'ansibeTower-icon',
    ChartSpikeIcon: 'chartSpike-icon',
    CloudServerIcon: 'cloudServer-icon',
};
var ICONS_CACHE = {};
var COMPONENTS_CACHE = {};
function findIconInRoots(roots, icon) {
    var _a, _b;
    var result = ICONS_CACHE[icon];
    if (result) {
        return result;
    }
    var nameSpecifier = icon.replace(/([A-Z])/g, function (g) { return "-".concat(g[0].toLowerCase()); }).replace(/^-/, '');
    var location = (_a = roots
        .map(function (root) {
        return glob.sync("".concat(root, "/node_modules/@patternfly/react-icons/dist/esm/**/").concat(iconMapper[icon] || nameSpecifier, ".js"));
    })
        .flat()) === null || _a === void 0 ? void 0 : _a[0];
    if (!location) {
        throw new Error("Cannot find source files for the ".concat(icon, " icon. Expected filename ").concat(nameSpecifier, ". It is possible the icon name does not match the filename pattern. You can look for the source file and add a new entry to the \"iconMapper\" object in your babel.config.js."));
    }
    return (_b = location.split('node_modules/').pop()) === null || _b === void 0 ? void 0 : _b.replace(/\.js$/, '').replace('/esm/', '/dynamic/');
}
function findPfRoots(roots, importName) {
    var _a, _b, _c, _d;
    if (COMPONENTS_CACHE[importName]) {
        return COMPONENTS_CACHE[importName];
    }
    var importTemplate = "@patternfly/react-core/dist/esm/**/".concat(importName, ".js");
    var componentSource = (_a = roots
        .map(function (root) {
        return glob.sync("".concat(root, "/node_modules/").concat(importTemplate));
    })
        .flat()) === null || _a === void 0 ? void 0 : _a[0];
    if (!componentSource && importName.match(PROPS_MATCH)) {
        componentSource = (_b = roots
            .map(function (root) {
            return glob.sync("".concat(root, "/node_modules/").concat(importTemplate.replace(/\.js$/, '').replace(PROPS_MATCH, ''), ".js"));
        })
            .flat()) === null || _b === void 0 ? void 0 : _b[0];
    }
    if (!componentSource && importName.match(VARIANT_MATCH)) {
        componentSource = (_c = roots
            .map(function (root) {
            return glob.sync("".concat(root, "/node_modules/").concat(importTemplate.replace(/\.js$/, '').replace(VARIANT_MATCH, ''), ".js"));
        })
            .flat()) === null || _c === void 0 ? void 0 : _c[0];
    }
    if (!componentSource && importName.match(POSITION_MATCH)) {
        componentSource = (_d = roots
            .map(function (root) {
            return glob.sync("".concat(root, "/node_modules/").concat(importTemplate.replace(/\.js$/, '').replace(POSITION_MATCH, ''), ".js"));
        })
            .flat()) === null || _d === void 0 ? void 0 : _d[0];
    }
    if (!componentSource) {
        throw new Error("Unable to find source file for ".concat(importName, "! Please find a source file for the component and add it to \"moduleOverrides\" argument of the createPfReactTransform babel plugin."));
    }
    componentSource = componentSource.split('/esm/').pop();
    var componentFragments = componentSource.split('/');
    componentFragments.pop();
    componentSource = "@patternfly/react-core/dist/dynamic/".concat(componentFragments.join('/'));
    COMPONENTS_CACHE[importName] = componentSource;
    return componentSource;
}
var MISMATCHED_CORE_MODULES = {
    getResizeObserver: 'helpers/resizeObserver',
    useOUIAProps: 'helpers/OUIA/ouia',
    OUIAProps: 'helpers/OUIA/ouia',
    getDefaultOUIAId: 'helpers/OUIA/ouia',
    useOUIAId: 'helpers/OUIA/ouia',
    handleArrows: 'helpers/KeyboardHandler',
    setTabIndex: 'helpers/KeyboardHandler',
    IconComponentProps: 'components/Icon',
    TreeViewDataItem: 'components/TreeView',
    clipboardCopyFunc: 'components/ClipboardCopy',
};
function populateCoreCache(roots, moduleOverrides) {
    if (Object.values(COMPONENTS_CACHE).length === 0) {
        Object.entries(__assign(__assign({}, MISMATCHED_CORE_MODULES), moduleOverrides)).forEach(function (_a) {
            var importName = _a[0], pathPartial = _a[1];
            var expectedPath = "@patternfly/react-core/dist/dynamic/".concat(pathPartial);
            var exists = roots.map(function (root) { return glob.sync("".concat(root, "/node_modules/").concat(expectedPath).replace(/\/\//, '/')); }).flat().length > 0;
            if (!exists) {
                throw new Error("No module found at ".concat(expectedPath, " while trying to resolve module overrides! Please verify that ").concat(pathPartial, " matches the desired ").concat(importName, " component source file path."));
            }
            COMPONENTS_CACHE[importName] = expectedPath;
        });
    }
}
var createPfReactTransform = function (roots, moduleOverrides) {
    if (roots === void 0) { roots = []; }
    if (moduleOverrides === void 0) { moduleOverrides = {}; }
    var internalRoots = __spreadArray([defaultRoot], roots, true);
    populateCoreCache(internalRoots, moduleOverrides);
    return [
        'transform-imports',
        {
            '@patternfly/react-core': {
                transform: function (importName) { return findPfRoots(internalRoots, importName); },
                preventFullImport: false,
                skipDefaultConversion: true,
            },
            '@patternfly/react-icons': {
                transform: function (importName) { return findIconInRoots(internalRoots, importName); },
                preventFullImport: true,
            },
        },
    ];
};
exports.default = createPfReactTransform;
module.exports = createPfReactTransform;
//# sourceMappingURL=babel-transform-imports.js.map