declare const getDynamicModules: (root: string) => {
    [moduleName: string]: {
        requiredVersion: string;
    };
};
export default getDynamicModules;
