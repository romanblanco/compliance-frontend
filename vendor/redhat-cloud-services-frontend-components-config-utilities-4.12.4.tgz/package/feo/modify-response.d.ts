import { FrontendCRD } from './feo-types';
export declare function modifyRequest(body: string, url: string, frontendCrd: FrontendCRD): string;
