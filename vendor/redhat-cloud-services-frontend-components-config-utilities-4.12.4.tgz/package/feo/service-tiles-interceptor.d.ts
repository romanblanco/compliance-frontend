import { FrontendCRD, ServicesTilesResponseEntry } from './feo-types';
declare function serviceTilesInterceptor(serviceCategories: ServicesTilesResponseEntry[], frontendCrd: FrontendCRD): ServicesTilesResponseEntry[];
export default serviceTilesInterceptor;
