export declare function matchNavigationRequest(url: string): boolean;
export declare function matchSearchIndexRequest(url: string): boolean;
export declare function matchServiceTilesRequest(url: string): boolean;
export declare function matchModulesRequest(url: string): boolean;
export declare function isInterceptAbleRequest(url: string): boolean;
