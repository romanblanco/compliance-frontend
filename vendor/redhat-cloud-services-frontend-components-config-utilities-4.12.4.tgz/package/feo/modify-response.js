"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.modifyRequest = modifyRequest;
var fec_logger_1 = __importStar(require("../fec-logger"));
var check_outgoing_requests_1 = require("./check-outgoing-requests");
var module_interceptor_1 = __importDefault(require("./module-interceptor"));
var navigation_interceptor_1 = __importDefault(require("./navigation-interceptor"));
var search_interceptor_1 = __importDefault(require("./search-interceptor"));
var service_tiles_interceptor_1 = __importDefault(require("./service-tiles-interceptor"));
function isGeneratedBundles(body, url) {
    return (0, check_outgoing_requests_1.matchNavigationRequest)(url);
}
function isSearchIndex(body, url) {
    return (0, check_outgoing_requests_1.matchSearchIndexRequest)(url);
}
function isServiceTiles(body, url) {
    return (0, check_outgoing_requests_1.matchServiceTilesRequest)(url);
}
function isModules(body, url) {
    return (0, check_outgoing_requests_1.matchModulesRequest)(url);
}
function modifyRequest(body, url, frontendCrd) {
    var objectToModify = JSON.parse(body);
    var payload = body;
    try {
        if (isGeneratedBundles(objectToModify, url)) {
            var resultBundles_1 = [];
            objectToModify.forEach(function (bundle) {
                var navItems = (0, navigation_interceptor_1.default)(frontendCrd, bundle, bundle.id);
                resultBundles_1.push(__assign(__assign({}, bundle), { navItems: navItems }));
            });
            payload = JSON.stringify(resultBundles_1);
        }
        else if (isSearchIndex(objectToModify, url)) {
            var staticSearch = objectToModify;
            var result = (0, search_interceptor_1.default)(staticSearch, frontendCrd);
            payload = JSON.stringify(result);
        }
        else if (isServiceTiles(objectToModify, url)) {
            var staticServicesTiles = objectToModify;
            var result = (0, service_tiles_interceptor_1.default)(staticServicesTiles, frontendCrd);
            payload = JSON.stringify(result);
        }
        else if (isModules(objectToModify, url)) {
            var modules = objectToModify;
            var result = (0, module_interceptor_1.default)(modules, frontendCrd);
            payload = JSON.stringify(result);
        }
        return payload;
    }
    catch (error) {
        (0, fec_logger_1.default)(fec_logger_1.LogType.error, "Error modifying proxy request via config interceptors: ".concat(error));
        return payload;
    }
}
//# sourceMappingURL=modify-response.js.map