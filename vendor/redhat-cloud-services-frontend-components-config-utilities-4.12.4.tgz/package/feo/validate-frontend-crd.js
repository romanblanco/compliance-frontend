"use strict";
var __makeTemplateObject = (this && this.__makeTemplateObject) || function (cooked, raw) {
    if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
    return cooked;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var _2020_1 = __importDefault(require("ajv/dist/2020"));
var js_yaml_1 = require("js-yaml");
var fs_1 = __importDefault(require("fs"));
var chalk_1 = __importDefault(require("chalk"));
var frontend_crd_schema_json_1 = __importDefault(require("./spec/frontend-crd.schema.json"));
function readCrdYaml(pathToCrd) {
    var data = fs_1.default.readFileSync(pathToCrd, 'utf8');
    return (0, js_yaml_1.load)(data);
}
function validateFrontendCrd(crd) {
    var _a, _b, _c;
    var validator = new _2020_1.default({
        strict: true,
    });
    var crdInternal = typeof crd === 'string' ? readCrdYaml(crd) : crd;
    delete frontend_crd_schema_json_1.default.$schema;
    var validate = validator.compile(frontend_crd_schema_json_1.default);
    var valid = validate(crdInternal);
    if (!valid) {
        (_a = validate.errors) === null || _a === void 0 ? void 0 : _a.forEach(function (error) {
            console.group();
            console.log(chalk_1.default.red(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\nFrontend CRD validation error:\n  - ", "\n    ", "\n    ", "\n    ", ""], ["\nFrontend CRD validation error:\n  - ", "\n    ", "\n    ", "\n    ", ""])), error.message, error.instancePath, error.keyword, JSON.stringify(error.params)));
            console.groupEnd();
        });
        var errorMessages = (_b = validate.errors) === null || _b === void 0 ? void 0 : _b.map(function (error) { return error.message; }).join(', ');
        throw new Error("Frontend CRD validation failed! ".concat(((_c = errorMessages === null || errorMessages === void 0 ? void 0 : errorMessages.length) !== null && _c !== void 0 ? _c : 0) > 0 ? errorMessages : 'Unable to validate frontend CRD'));
    }
}
exports.default = validateFrontendCrd;
var templateObject_1;
//# sourceMappingURL=validate-frontend-crd.js.map