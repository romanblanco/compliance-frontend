import { Response } from 'express';
declare function serveLocalFile(url: string, path: string, target?: string): {
    context: (path: string) => boolean;
    target: string;
    secure: boolean;
    changeOrigin: boolean;
    autoRewrite: boolean;
    selfHandleResponse: boolean;
    onProxyReq: (_pr: unknown, _req: unknown, res: Response) => void;
};
export default serveLocalFile;
