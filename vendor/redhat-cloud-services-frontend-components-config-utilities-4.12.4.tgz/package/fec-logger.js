"use strict";
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var _a, _b;
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogType = void 0;
var chalk_1 = __importDefault(require("chalk"));
var PREFIX = '[fec]';
var ERROR_LEVEL = "".concat(PREFIX, " Error");
var WARN_LEVEL = "".concat(PREFIX, " Warn");
var INFO_LEVEL = "".concat(PREFIX, " Info");
var DEBUG_LEVEL = "".concat(PREFIX, " Debug");
var LogType;
(function (LogType) {
    LogType["error"] = "[fec] Error";
    LogType["warn"] = "[fec] Warn";
    LogType["info"] = "[fec] Info";
    LogType["debug"] = "[fec] Debug";
})(LogType || (exports.LogType = LogType = {}));
var colors = (_a = {},
    _a[LogType.error] = chalk_1.default.red,
    _a[LogType.warn] = chalk_1.default.yellow,
    _a[LogType.info] = chalk_1.default.blue,
    _a[LogType.debug] = chalk_1.default.magenta,
    _a);
var logFunctions = (_b = {},
    _b[LogType.error] = console.error,
    _b[LogType.warn] = console.warn,
    _b[LogType.info] = console.info,
    _b[LogType.debug] = console.debug,
    _b);
function getFecMessage(level) {
    var data = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        data[_i - 1] = arguments[_i];
    }
    logFunctions[level].apply(logFunctions, __spreadArray(["".concat(colors[level](level), ": ")], data, false));
}
exports.default = getFecMessage;
module.exports = getFecMessage;
module.exports.LogType = LogType;
//# sourceMappingURL=fec-logger.js.map