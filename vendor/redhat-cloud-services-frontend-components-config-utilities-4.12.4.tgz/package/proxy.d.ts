import type { Configuration } from 'webpack-dev-server';
type ProxyConfigItem = import('webpack-dev-server').ProxyConfigArrayItem;
export type ProxyOptions = {
    env?: 'prod-stable' | 'stage-stable' | string;
    customProxy?: ProxyConfigItem[];
    routes?: {
        routes?: {
            [route: string]: ProxyConfigItem;
        };
    } & {
        [route: string]: ProxyConfigItem;
    };
    routesPath?: string;
    useProxy?: boolean;
    proxyURL?: string;
    standalone?: boolean;
    port?: number;
    reposDir?: string;
    localChrome?: string;
    appUrl?: (string | RegExp)[];
    publicPath: string;
    proxyVerbose?: boolean;
    useCloud?: boolean;
    target?: string;
    keycloakUri?: string;
    registry?: ((...args: any[]) => void)[];
    isChrome?: boolean;
    onBeforeSetupMiddleware?: (opts: {
        chromePath?: string;
    }) => void;
    bounceProd?: boolean;
    useAgent?: boolean;
    useDevBuild?: boolean;
    localApps?: string;
    blockLegacyChrome?: boolean;
    frontendCRDPath?: string;
};
declare const proxy: ({ env, customProxy, routes, routesPath, useProxy, proxyURL, appUrl, publicPath, proxyVerbose, useCloud, target, bounceProd, useAgent, localApps, frontendCRDPath, }: ProxyOptions) => Configuration;
export default proxy;
