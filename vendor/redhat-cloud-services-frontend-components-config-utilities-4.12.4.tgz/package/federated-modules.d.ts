import { DynamicRemotePlugin, EncodedExtension, PluginBuildMetadata, WebpackSharedConfig } from '@openshift/dynamic-plugin-sdk-webpack';
import fecLogger from './fec-logger';
export declare const createIncludes: () => {
    chromeProvided: Record<string, WebpackSharedConfig>;
    defaultShared: Record<string, WebpackSharedConfig>;
    impliedDeps: Record<string, string[]>;
};
export type FederatedModulesConfig = {
    root: string;
    dependencies?: Record<string, string>;
    exposes?: {
        [module: string]: string;
    };
    shared?: {
        [module: string]: WebpackSharedConfig;
    }[];
    debug?: boolean;
    moduleName?: string;
    useFileHash?: boolean;
    separateRuntime?: boolean;
    exclude?: string[];
    bundleChromeShared?: boolean;
    eager?: boolean;
    pluginMetadata?: PluginBuildMetadata;
    extensions?: EncodedExtension[];
};
export declare const bundleChromeSharedLocally: (root: string, sharedModules?: Record<string, WebpackSharedConfig>) => Record<string, WebpackSharedConfig>;
export declare const createSharedDeps: (include: {
    [module: string]: WebpackSharedConfig;
}, dependencies: {
    [pkg: string]: string;
}, exclude: string[]) => {
    [module: string]: WebpackSharedConfig;
};
export declare const applyImpliedDeps: (sharedDeps: Record<string, WebpackSharedConfig>, include: Record<string, WebpackSharedConfig>, dependencies: Record<string, string>, impliedDeps: Record<string, string[]>) => Record<string, WebpackSharedConfig>;
export declare const mergeSharedDeps: (sharedDeps: Record<string, WebpackSharedConfig>, shared: Record<string, WebpackSharedConfig>[], chromeProvided: Record<string, WebpackSharedConfig>, logger?: typeof fecLogger) => Record<string, WebpackSharedConfig>;
declare const federatedModules: ({ root, dependencies: depsProp, exposes, shared, debug, moduleName, useFileHash, separateRuntime, exclude, bundleChromeShared, eager, pluginMetadata, extensions, }: FederatedModulesConfig) => DynamicRemotePlugin;
export default federatedModules;
