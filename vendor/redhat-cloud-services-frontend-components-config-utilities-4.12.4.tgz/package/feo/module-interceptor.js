"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var jsVarName_1 = __importDefault(require("../jsVarName"));
function moduleInterceptor(moduleRegistry, frontendCRD) {
    var _a;
    var moduleName = (0, jsVarName_1.default)(frontendCRD.objects[0].metadata.name);
    var cdnPath = frontendCRD.objects[0].spec.frontend.paths[0];
    return __assign(__assign({}, moduleRegistry), (_a = {}, _a[moduleName] = __assign(__assign({}, frontendCRD.objects[0].spec.module), { cdnPath: cdnPath }), _a));
}
exports.default = moduleInterceptor;
//# sourceMappingURL=module-interceptor.js.map