import { FrontendCRD } from './feo-types';
export declare function readFrontendCRD(crdPath: string): FrontendCRD;
export declare function hasFEOFeaturesEnabled(crd: FrontendCRD): boolean;
