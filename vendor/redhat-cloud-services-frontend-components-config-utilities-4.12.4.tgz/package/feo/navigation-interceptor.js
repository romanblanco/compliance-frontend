"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
function hasSegmentRef(item) {
    var _a, _b;
    return typeof ((_a = item === null || item === void 0 ? void 0 : item.segmentRef) === null || _a === void 0 ? void 0 : _a.segmentId) === 'string' && typeof ((_b = item === null || item === void 0 ? void 0 : item.segmentRef) === null || _b === void 0 ? void 0 : _b.frontendName) === 'string';
}
var bundleSegmentsCache = {};
var navSegmentCache = {};
var getBundleSegments = function (segmentCache, bundleId) {
    return Object.values(segmentCache)
        .filter(function (segment) { return segment.bundleId === bundleId; })
        .reduce(function (acc, curr) {
        acc[curr.segmentId] = curr;
        return acc;
    }, {});
};
function findMatchingSegmentItem(navItems, matchId) {
    var match = navItems.find(function (item) {
        if (!hasSegmentRef(item)) {
            return item.id === matchId;
        }
        return false;
    });
    if (!match) {
        for (var i = 0; navItems[i] && !match; i += 1) {
            var curr = navItems[i];
            if (!hasSegmentRef(curr) && curr.routes) {
                match = findMatchingSegmentItem(curr.routes, matchId);
            }
            else if (!hasSegmentRef(curr) && curr.navItems) {
                match = findMatchingSegmentItem(curr.navItems, matchId);
            }
        }
    }
    return match;
}
function handleNestedNav(segmentMatch, originalNavItem, bSegmentCache, nSegmentCache, bundleId, currentFrontendName, parentSegment) {
    var routes = segmentMatch.routes, navItems = segmentMatch.navItems, segmentItem = __rest(segmentMatch, ["routes", "navItems"]);
    var parsedRoutes = originalNavItem.routes;
    var parsedNavItems = originalNavItem.navItems;
    if (routes && routes.length > 0) {
        var remoteRoutes = originalNavItem.routes || [];
        var remoteRoutesMap_1 = new Map(remoteRoutes.map(function (route) { return [route.id, route]; }));
        var mergedRoutes_1 = routes.map(function (localRoute) {
            if (localRoute.id && remoteRoutesMap_1.has(localRoute.id)) {
                var remoteRoute = remoteRoutesMap_1.get(localRoute.id);
                return __assign(__assign({}, remoteRoute), localRoute);
            }
            return localRoute;
        });
        remoteRoutes.forEach(function (remoteRoute) {
            if (remoteRoute.id && !routes.some(function (localRoute) { return localRoute.id === remoteRoute.id; })) {
                mergedRoutes_1.push(remoteRoute);
            }
        });
        parsedRoutes = parseNavItems(mergedRoutes_1, bSegmentCache, nSegmentCache, bundleId, currentFrontendName);
    }
    else if (parsedRoutes) {
        parsedRoutes = parseNavItems(parsedRoutes, bSegmentCache, nSegmentCache, bundleId, currentFrontendName);
    }
    if (navItems && navItems.length > 0) {
        var remoteNavItems = originalNavItem.navItems || [];
        var remoteNavItemsMap_1 = new Map(remoteNavItems.map(function (navItem) { return [navItem.id, navItem]; }));
        var mergedNavItems_1 = navItems.map(function (localNavItem) {
            if (localNavItem.id && remoteNavItemsMap_1.has(localNavItem.id)) {
                var remoteNavItem = remoteNavItemsMap_1.get(localNavItem.id);
                return __assign(__assign({}, remoteNavItem), localNavItem);
            }
            return localNavItem;
        });
        remoteNavItems.forEach(function (remoteNavItem) {
            if (remoteNavItem.id && !navItems.some(function (localNavItem) { return localNavItem.id === remoteNavItem.id; })) {
                mergedNavItems_1.push(remoteNavItem);
            }
        });
        parsedNavItems = parseNavItems(mergedNavItems_1, bSegmentCache, nSegmentCache, bundleId, currentFrontendName);
    }
    else if (parsedNavItems) {
        parsedNavItems = parseNavItems(parsedNavItems, bSegmentCache, nSegmentCache, bundleId, currentFrontendName);
    }
    return __assign(__assign(__assign({}, originalNavItem), segmentItem), { position: parentSegment.position, routes: parsedRoutes, navItems: parsedNavItems });
}
function findNavItemsFirstSegmentIndex(navItems, frontendName) {
    return navItems.findIndex(function (item) {
        return hasSegmentRef(item) && item.segmentRef.frontendName === frontendName;
    });
}
function findSegmentSequenceLength(navItems, sequenceStartIndex, sementId, frontendName) {
    var _a;
    var finalIndex = sequenceStartIndex;
    for (var i = sequenceStartIndex; i < navItems.length; i += 1) {
        var item = navItems[i];
        var prev = navItems[i - 1];
        if (!prev) {
            finalIndex = i;
            continue;
        }
        if (((_a = item.segmentRef) === null || _a === void 0 ? void 0 : _a.segmentId) === sementId && item.segmentRef.frontendName === frontendName) {
            finalIndex = i;
        }
        else {
            i = navItems.length;
        }
    }
    return finalIndex - sequenceStartIndex + 1;
}
function parseNavItems(navItems, bSegmentCache, nSegmentCache, bundleId, currentFrontendName) {
    var relevantSegments = getBundleSegments(bSegmentCache, bundleId);
    var res = navItems.map(function (navItem) {
        if (!hasSegmentRef(navItem) && navItem.id) {
            var id = navItem.id, bundleSegmentRef = navItem.bundleSegmentRef;
            if (navItem.frontendRef === currentFrontendName && bundleSegmentRef && relevantSegments[bundleSegmentRef]) {
                var parentSegment = relevantSegments[bundleSegmentRef];
                var segmentItemMatch = findMatchingSegmentItem(relevantSegments[bundleSegmentRef].navItems, id);
                if (segmentItemMatch && !hasSegmentRef(segmentItemMatch)) {
                    return handleNestedNav(segmentItemMatch, navItem, bSegmentCache, nSegmentCache, bundleId, currentFrontendName, parentSegment);
                }
            }
            else if (typeof navItem.groupId === 'string' && navItem.groupId.length > 0) {
                navItem.navItems = parseNavItems(navItem.navItems || [], bSegmentCache, nSegmentCache, bundleId, currentFrontendName);
                return navItem;
            }
        }
        return navItem;
    });
    var segmentIndex = findNavItemsFirstSegmentIndex(res, currentFrontendName);
    var iterations = 0;
    while (segmentIndex > -1 && iterations < 100) {
        var segment = res[segmentIndex];
        if (hasSegmentRef(segment)) {
            var replacement = nSegmentCache[segment.segmentRef.segmentId];
            if (replacement && replacement.navItems) {
                var replaceLength = findSegmentSequenceLength(res, segmentIndex, segment.segmentRef.segmentId, currentFrontendName);
                var nestedNavItems = replacement.navItems.map(function (navItem) {
                    if (navItem.routes) {
                        return __assign(__assign({}, navItem), { routes: parseNavItems(navItem.routes, bSegmentCache, nSegmentCache, bundleId, currentFrontendName) });
                    }
                    else if (navItem.navItems) {
                        return __assign(__assign({}, navItem), { navItems: parseNavItems(navItem.navItems, bSegmentCache, nSegmentCache, bundleId, currentFrontendName) });
                    }
                    return navItem;
                });
                res.splice.apply(res, __spreadArray([segmentIndex, replaceLength], nestedNavItems, false));
            }
        }
        segmentIndex = findNavItemsFirstSegmentIndex(res, currentFrontendName);
        iterations += 1;
    }
    return res;
}
var substituteLocalNav = function (frontendCRD, nav, bundleName) {
    var res = [];
    var bundleSegmentsCache = {};
    var navSegmentCache = {};
    frontendCRD.objects.forEach(function (obj) {
        var bundleSegments = obj.spec.bundleSegments || [];
        bundleSegments.forEach(function (bundleSegment) {
            bundleSegmentsCache[bundleSegment.segmentId] = bundleSegment;
        });
        var navSegments = obj.spec.navigationSegments || [];
        navSegments.forEach(function (navSegment) {
            if (navSegment.segmentId) {
                navSegmentCache[navSegment.segmentId] = navSegment;
            }
        });
        var missingSegments = __spreadArray([], (obj.spec.bundleSegments || []), true).filter(function (segment) {
            if (segment.bundleId !== bundleName) {
                return false;
            }
            return !nav.navItems.find(function (navItem) {
                return navItem.bundleSegmentRef === segment.segmentId;
            });
        });
        var missingNavItems = missingSegments
            .map(function (segment) { return segment.navItems.map(function (navItem) { return (__assign(__assign({}, navItem), { position: segment.position })); }); })
            .flat();
        var presentSegments = __spreadArray([], (obj.spec.bundleSegments || []), true).filter(function (segment) {
            if (segment.bundleId !== bundleName) {
                return false;
            }
            return nav.navItems.some(function (navItem) { return navItem.bundleSegmentRef === segment.segmentId; });
        });
        presentSegments.forEach(function (segment) {
            segment.navItems.forEach(function (segmentNavItem) {
                if (segmentNavItem.segmentRef)
                    return;
                if (!segmentNavItem.id)
                    return;
                if (!nav.navItems.some(function (remoteItem) { return remoteItem.id === segmentNavItem.id; })) {
                    missingNavItems.push(__assign(__assign({}, segmentNavItem), { position: segment.position }));
                }
            });
        });
        var parseInput = __spreadArray(__spreadArray([], nav.navItems, true), missingNavItems, true);
        res = parseNavItems(parseInput, bundleSegmentsCache, navSegmentCache, bundleName, obj.metadata.name);
    });
    res.sort(function (a, b) {
        if (typeof a.position !== 'number' || typeof b.position !== 'number') {
            return 0;
        }
        return a.position - b.position;
    });
    return res;
};
exports.default = substituteLocalNav;
//# sourceMappingURL=navigation-interceptor.js.map