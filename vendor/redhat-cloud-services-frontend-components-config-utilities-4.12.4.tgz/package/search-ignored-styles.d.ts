declare const searchIgnoredStyles: (root: string, ...paths: string[]) => {};
export default searchIgnoredStyles;
