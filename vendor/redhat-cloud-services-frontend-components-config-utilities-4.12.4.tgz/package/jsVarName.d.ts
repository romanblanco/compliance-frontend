declare function jsVarName(s: string): string;
export default jsVarName;
