import { DynamicRemotePluginOptions, PluginRuntimeMetadata } from '@openshift/dynamic-plugin-sdk-webpack';
import { Compiler } from 'webpack';
export type ExtensionsMapperOptions = {
    pluginManifestFile?: string;
    remoteEntryFile?: string;
    remoteEntryCallback?: string;
};
declare class ExtensionsMapper {
    options: Required<ExtensionsMapperOptions>;
    plugin: Partial<DynamicRemotePluginOptions & PluginRuntimeMetadata>;
    constructor(plugin: DynamicRemotePluginOptions & PluginRuntimeMetadata, options: ExtensionsMapperOptions);
    apply(compiler: Compiler): void;
}
export default ExtensionsMapper;
