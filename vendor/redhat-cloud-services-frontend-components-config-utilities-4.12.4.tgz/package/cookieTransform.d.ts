import { Request as ExpressRequest, Response } from 'express';
import type * as http from 'http';
export type Entitlement = {
    is_entitled?: boolean;
    is_trial?: boolean;
};
declare function cookieTransform(proxyReq: http.ClientRequest, req: ExpressRequest, _res: Response, { entitlements, user, internal, identity: customIdentity, }: {
    entitlements?: {
        [sku: string]: Entitlement;
    };
    user: any;
    internal: any;
    identity: any;
}): void;
export default cookieTransform;
