"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var jws_1 = __importDefault(require("jws"));
var defaultEntitlements = {
    insights: { is_entitled: true },
    smart_management: { is_entitled: true },
    openshift: { is_entitled: true },
    hybrid: { is_entitled: true },
    migrations: { is_entitled: true },
    ansible: { is_entitled: true },
    cost_management: { is_entitled: true },
};
function cookieTransform(proxyReq, req, _res, _a) {
    var _b = _a.entitlements, entitlements = _b === void 0 ? defaultEntitlements : _b, user = _a.user, internal = _a.internal, customIdentity = _a.identity;
    var _c = req.headers, cookie = _c.cookie, authorization = _c.authorization;
    var match = (cookie === null || cookie === void 0 ? void 0 : cookie.match(/cs_jwt=([^;]+)/)) || (authorization === null || authorization === void 0 ? void 0 : authorization.match(/^Bearer (.*)$/));
    if (match) {
        var cs_jwt = match[1];
        var sig = jws_1.default.decode(cs_jwt);
        if (!sig) {
            return;
        }
        var payload = sig.payload;
        var identity = {
            entitlements: entitlements,
            identity: __assign(__assign({ type: 'User', auth_type: 'basic-auth', account_number: payload.account_number + '', org_id: payload.org_id }, customIdentity), { user: __assign({ username: payload.username, email: payload.email, first_name: payload.first_name, last_name: payload.last_name, is_active: true, is_org_admin: payload.is_org_admin, is_internal: payload.is_internal, locale: 'en-US', user_id: payload.account_id + '' }, user), internal: __assign({ org_id: payload.org_id, auth_time: payload.auth_time }, internal) }),
        };
        var identityB64 = Buffer.from(JSON.stringify(identity), 'utf8').toString('base64');
        proxyReq.setHeader('x-rh-identity', identityB64);
    }
}
exports.default = cookieTransform;
module.exports = cookieTransform;
//# sourceMappingURL=cookieTransform.js.map