"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function serveLocalFile(url, path, target) {
    if (target === void 0) { target = 'https://ci.cloud.redhat.com'; }
    console.warn("\x1b[33mserveLocalFile is deprecated in favor of hooking into webpack-dev-server's express app.");
    console.warn('See https://github.com/RedHatInsights/frontend-components/blob/master/packages/config/README.md#standalone');
    return {
        context: function (path) { return path.includes(url); },
        target: target,
        secure: false,
        changeOrigin: true,
        autoRewrite: true,
        selfHandleResponse: true,
        onProxyReq: function (_pr, _req, res) {
            res.sendFile(path);
        },
    };
}
exports.default = serveLocalFile;
module.exports = serveLocalFile;
//# sourceMappingURL=serveLocalFile.js.map