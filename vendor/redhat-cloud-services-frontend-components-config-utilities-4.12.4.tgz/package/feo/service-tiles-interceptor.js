"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
function serviceTilesInterceptor(serviceCategories, frontendCrd) {
    var _a, _b;
    var frontendRef = frontendCrd.objects[0].metadata.name;
    var result = __spreadArray([], serviceCategories, true);
    var frontendCategories = (_b = (_a = frontendCrd.objects[0].spec.serviceTiles) === null || _a === void 0 ? void 0 : _a.reduce(function (acc, tile) {
        var section = tile.section;
        var group = tile.group;
        if (!acc[section]) {
            acc[section] = {};
        }
        if (!acc[section][group]) {
            acc[section][group] = [];
        }
        acc[section][group].push(__assign({}, tile));
        return acc;
    }, {})) !== null && _b !== void 0 ? _b : {};
    result = result.map(function (category) {
        var newGroups = category.links.map(function (group) {
            var _a, _b;
            var newTiles = group.links.filter(function (tile) { return tile.frontendRef !== frontendRef; });
            return __assign(__assign({}, group), { links: __spreadArray(__spreadArray([], newTiles, true), ((_b = (_a = frontendCategories[category.id]) === null || _a === void 0 ? void 0 : _a[group.id]) !== null && _b !== void 0 ? _b : []), true) });
        });
        return __assign(__assign({}, category), { links: newGroups });
    });
    return result;
}
exports.default = serviceTilesInterceptor;
//# sourceMappingURL=service-tiles-interceptor.js.map