declare function federate(argv: Record<string, any>, cwd: string): void;
export default federate;
