"use strict";
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
function widgetRegistryInterceptor(widgetEntries, frontendCrd) {
    var _a;
    var frontendName = frontendCrd.objects[0].metadata.name;
    var result = widgetEntries.filter(function (entry) { return entry.frontendRef !== frontendName; });
    return __spreadArray(__spreadArray([], result, true), ((_a = frontendCrd.objects[0].spec.widgetRegistry) !== null && _a !== void 0 ? _a : []), true);
}
exports.default = widgetRegistryInterceptor;
//# sourceMappingURL=widget-registry-interceptor.js.map