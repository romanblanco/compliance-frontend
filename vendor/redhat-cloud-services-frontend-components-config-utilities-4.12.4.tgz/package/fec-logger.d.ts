export declare enum LogType {
    error = "[fec] Error",
    warn = "[fec] Warn",
    info = "[fec] Info",
    debug = "[fec] Debug"
}
declare function getFecMessage(level: LogType, ...data: any[]): void;
export default getFecMessage;
