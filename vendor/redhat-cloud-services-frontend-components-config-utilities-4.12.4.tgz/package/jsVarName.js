"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function jsVarName(s) {
    return (s
        .replace(/-(\w)/g, function (_, match) { return match.toUpperCase(); })
        .replace(/^[0-9]+/, '')
        .replace(/[^A-Za-z0-9]+/g, ''));
}
exports.default = jsVarName;
module.exports = jsVarName;
//# sourceMappingURL=jsVarName.js.map