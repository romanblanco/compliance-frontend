export declare const resolveSharedImportPath: (root: string, moduleName: string) => string | null;
