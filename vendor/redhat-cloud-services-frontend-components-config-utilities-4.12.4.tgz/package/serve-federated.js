"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var path_1 = __importDefault(require("path"));
var fs_1 = __importDefault(require("fs"));
var concurrently_1 = __importDefault(require("concurrently"));
var crd_check_1 = require("./feo/crd-check");
var _1 = require(".");
function federate(argv, cwd) {
    var _a, _b, _c;
    process.env.FEC_STATIC = 'true';
    var configPath = argv.config || './node_modules/@redhat-cloud-services/frontend-components-config/bin/prod.webpack.config.js';
    if (typeof configPath !== 'string') {
        console.error('Invalid webpack config path!');
        process.exit(1);
    }
    configPath = path_1.default.join(cwd, configPath);
    var fecConfig = require(process.env.FEC_CONFIG_PATH);
    var insights = require("".concat(cwd, "/package.json")).insights;
    var frontendCRDPath = (_a = fecConfig.frontendCRDPath) !== null && _a !== void 0 ? _a : path_1.default.resolve(process.cwd(), 'deploy/frontend.yaml');
    var frontendCrdRef = { current: undefined };
    var FEOFeaturesEnabled = false;
    try {
        frontendCrdRef.current = (0, crd_check_1.readFrontendCRD)(frontendCRDPath);
        FEOFeaturesEnabled = (0, crd_check_1.hasFEOFeaturesEnabled)(frontendCrdRef.current);
    }
    catch (e) {
        (0, _1.fecLogger)(_1.LogType.warn, "FEO features are not enabled. Unable to find frontend CRD file at ".concat(frontendCRDPath, ". If you want FEO features for local development, make sure to have a \"deploy/frontend.yaml\" file in your project or specify its location via \"frontendCRDPath\" attribute."));
    }
    try {
        fs_1.default.statSync(configPath);
        var config = require(configPath);
        if (typeof config === 'function') {
            config = config(process.env);
        }
        var cdnPath_1;
        if (FEOFeaturesEnabled && fecConfig.publicPath === 'auto' && frontendCrdRef.current) {
            cdnPath_1 = "".concat((_c = (_b = frontendCrdRef.current) === null || _b === void 0 ? void 0 : _b.objects[0]) === null || _c === void 0 ? void 0 : _c.spec.frontend.paths[0], "/").replace(/\/\//, '/');
        }
        else if (fecConfig.publicPath === 'auto') {
            cdnPath_1 = "/".concat(fecConfig.deployment || 'apps', "/").concat(insights.appname, "/");
        }
        else {
            cdnPath_1 = config.output.publicPath;
        }
        Promise.resolve(config).then(function (config) {
            var outputPath = config.output.path;
            (0, concurrently_1.default)([
                "npm exec -- webpack --config ".concat(configPath, " --watch --output-path ").concat(path_1.default.join(outputPath, cdnPath_1)),
                "npm exec -- http-server ".concat(outputPath, " -p ").concat(argv.port || 8003, " -c-1 -a :: --cors=*"),
            ]);
        });
    }
    catch (error) {
        console.error(error);
        process.exit(1);
    }
}
exports.default = federate;
module.exports = federate;
//# sourceMappingURL=serve-federated.js.map