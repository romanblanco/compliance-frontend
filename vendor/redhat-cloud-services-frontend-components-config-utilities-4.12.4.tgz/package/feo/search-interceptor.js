"use strict";
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
function searchInterceptor(staticSearchIndex, frontendCRD) {
    var _a;
    var frontendRef = frontendCRD.objects[0].metadata.name;
    var result = staticSearchIndex.filter(function (entry) { return entry.frontendRef !== frontendRef; });
    return __spreadArray(__spreadArray([], result, true), ((_a = frontendCRD.objects[0].spec.searchEntries) !== null && _a !== void 0 ? _a : []), true);
}
exports.default = searchInterceptor;
//# sourceMappingURL=search-interceptor.js.map