import { ChromeWidgetEntry, FrontendCRD } from './feo-types';
declare function widgetRegistryInterceptor(widgetEntries: ChromeWidgetEntry[], frontendCrd: FrontendCRD): ChromeWidgetEntry[];
export default widgetRegistryInterceptor;
