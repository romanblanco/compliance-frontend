"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var webpack_1 = __importDefault(require("webpack"));
var ExtensionsMapper = (function () {
    function ExtensionsMapper(plugin, options) {
        if (!plugin) {
            throw new Error('Missing plugin config!');
        }
        this.plugin = plugin;
        this.options = __assign({ remoteEntryCallback: 'window.loadPluginEntry', remoteEntryFile: 'plugin-entry.js', pluginManifestFile: 'plugin-manifest.json' }, options);
    }
    ExtensionsMapper.prototype.apply = function (compiler) {
        var _this = this;
        compiler.hooks.thisCompilation.tap(ExtensionsMapper.name, function (compilation) {
            compilation.hooks.processAssets.tap({
                name: ExtensionsMapper.name,
                stage: webpack_1.default.Compilation.PROCESS_ASSETS_STAGE_ADDITIONAL,
            }, function () {
                compilation.emitAsset(_this.options.pluginManifestFile, new webpack_1.default.sources.RawSource(Buffer.from(JSON.stringify(__assign({ version: '0.0.0', description: '', displayName: '', dependencies: {}, disableStaticPlugins: {} }, _this.plugin), null, 2))));
            });
            compilation.hooks.processAssets.tap({
                name: ExtensionsMapper.name,
                stage: webpack_1.default.Compilation.PROCESS_ASSETS_STAGE_ADDITIONS,
            }, function () {
                compilation.updateAsset(_this.options.remoteEntryFile, function (source) {
                    var newSource = new webpack_1.default.sources.ReplaceSource(source);
                    var fromIndex = source.source().toString().indexOf("".concat(_this.options.remoteEntryCallback, "("));
                    if (fromIndex < 0) {
                        var error = new webpack_1.default.WebpackError("Missing call to ".concat(_this.options.remoteEntryCallback));
                        error.file = _this.options.remoteEntryFile;
                        compilation.errors.push(error);
                    }
                    else {
                        newSource.insert(fromIndex + _this.options.remoteEntryCallback.length + 1, "'".concat(_this.plugin.name, "@").concat(_this.plugin.version, "', "));
                    }
                    return newSource;
                });
            });
        });
    };
    return ExtensionsMapper;
}());
exports.default = ExtensionsMapper;
//# sourceMappingURL=extension-mapper.js.map