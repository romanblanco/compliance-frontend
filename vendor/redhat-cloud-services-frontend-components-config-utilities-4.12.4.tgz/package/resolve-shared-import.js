"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveSharedImportPath = void 0;
var path_1 = require("path");
var resolveSharedImportPath = function (root, moduleName) {
    try {
        return require.resolve(moduleName, { paths: [(0, path_1.resolve)(root)] });
    }
    catch (_a) {
        return null;
    }
};
exports.resolveSharedImportPath = resolveSharedImportPath;
//# sourceMappingURL=resolve-shared-import.js.map