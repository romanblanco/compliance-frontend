import { FrontendCRD } from './feo-types';
declare function validateFrontendCrd(pathToCrd: string): void;
declare function validateFrontendCrd(crd: FrontendCRD): void;
export default validateFrontendCrd;
