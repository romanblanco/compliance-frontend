"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var path_1 = __importDefault(require("path"));
var glob = __importStar(require("glob"));
var fs_1 = __importDefault(require("fs"));
var chalk_1 = __importDefault(require("chalk"));
var checkPfVersion = function (version) {
    var number = version === null || version === void 0 ? void 0 : version.replace(/[^0-9]/g, '');
    try {
        var versionInt = Number(number);
        return versionInt >= 500;
    }
    catch (error) {
        console.log(chalk_1.default.yellow("Unable to parse PF package version: ".concat(version, ".")));
        return false;
    }
};
var getDynamicModules = function (root) {
    if (!root) {
        throw new Error('Provide a directory of your node_modules to find dynamic modules');
    }
    var packageFile = fs_1.default.readFileSync(path_1.default.resolve(root, 'package.json'), { encoding: 'utf-8' });
    var packageJSON = JSON.parse(packageFile);
    var coreVersion = packageJSON.dependencies['@patternfly/react-core'] || packageJSON.devDependencies['@patternfly/react-core'];
    var iconsVersion = packageJSON.dependencies['@patternfly/react-icons'] || packageJSON.devDependencies['@patternfly/react-icons'];
    var coreValid = checkPfVersion(coreVersion);
    var iconsValid = checkPfVersion(iconsVersion);
    if (!coreValid) {
        console.log(chalk_1.default.yellow('[fec]'), "Unsupported @patternfly packages version. Dynamic modules require version ^5.0.0. Got ".concat(coreVersion, "."));
        return {};
    }
    if (!iconsValid) {
        console.log(chalk_1.default.yellow('[fec]'), "Unsupported @patternfly packages version. Dynamic modules require version ^5.0.0. Got ".concat(iconsVersion, "."));
        return {};
    }
    var componentsGlob = path_1.default.resolve(root, 'node_modules/@patternfly/react-core/dist/dynamic/*/**/package.json');
    var iconsGlob = path_1.default.resolve(root, 'node_modules/@patternfly/react-icons/dist/dynamic/*/**/package.json');
    var files = [
        { requiredVersion: coreVersion, files: glob.sync(componentsGlob) },
        { requiredVersion: iconsVersion, files: glob.sync(iconsGlob) },
    ];
    var modules = files
        .map(function (_a) {
        var files = _a.files, requiredVersion = _a.requiredVersion;
        return files.reduce(function (acc, curr) {
            var _a;
            var moduleName = curr
                .replace(/\/package.json$/, '')
                .split('/node_modules/')
                .pop();
            if (!moduleName) {
                throw new Error("Unable to get module name from: ".concat(curr));
            }
            return __assign(__assign({}, acc), (_a = {}, _a[moduleName] = {
                requiredVersion: requiredVersion,
            }, _a));
        }, {});
    })
        .reduce(function (acc, curr) { return (__assign(__assign({}, acc), curr)); }, {});
    return modules;
};
exports.default = getDynamicModules;
module.exports = getDynamicModules;
//# sourceMappingURL=generate-pf-shared-assets-list.js.map