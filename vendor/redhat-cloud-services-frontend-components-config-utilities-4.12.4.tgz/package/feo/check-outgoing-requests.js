"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.matchNavigationRequest = matchNavigationRequest;
exports.matchSearchIndexRequest = matchSearchIndexRequest;
exports.matchServiceTilesRequest = matchServiceTilesRequest;
exports.matchModulesRequest = matchModulesRequest;
exports.isInterceptAbleRequest = isInterceptAbleRequest;
function matchNavigationRequest(url) {
    return !!url.match(/\/api\/chrome-service\/v1\/static\/bundles-generated\.json/);
}
function matchSearchIndexRequest(url) {
    return !!url.match(/\/api\/chrome-service\/v1\/static\/search-index-generated\.json/);
}
function matchServiceTilesRequest(url) {
    return !!url.match(/\/api\/chrome-service\/v1\/static\/service-tiles-generated\.json/);
}
function matchModulesRequest(url) {
    return !!url.match(/\/api\/chrome-service\/v1\/static\/fed-modules-generated\.json/);
}
function isInterceptAbleRequest(url) {
    var checks = [matchNavigationRequest, matchSearchIndexRequest, matchServiceTilesRequest, matchModulesRequest];
    return checks.some(function (check) { return check(url); });
}
//# sourceMappingURL=check-outgoing-requests.js.map