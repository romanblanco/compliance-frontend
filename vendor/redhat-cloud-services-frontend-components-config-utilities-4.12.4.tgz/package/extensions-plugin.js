"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var path_1 = require("path");
var federated_modules_1 = __importDefault(require("./federated-modules"));
var extension_mapper_1 = __importDefault(require("./extension-mapper"));
var ExtensionsPlugin = (function () {
    function ExtensionsPlugin(plugin, fedMod, options) {
        if (!plugin) {
            throw new Error('Missing plugin config!');
        }
        this.plugin = plugin;
        this.fedMod = __assign({ moduleName: 'plugin-entry', libName: 'window.loadPluginEntry', useFileHash: false, libType: 'jsonp' }, fedMod);
        this.options = __assign({ remoteEntryCallback: 'window.loadPluginEntry', remoteEntryFile: "".concat(this.fedMod.moduleName, ".js"), pluginManifestFile: 'plugin-manifest.json' }, options);
    }
    ExtensionsPlugin.prototype.apply = function (compiler) {
        var root = this.fedMod.root || compiler.context;
        var _a = require((0, path_1.resolve)(root, './package.json')) || {}, insights = _a.insights, version = _a.version, description = _a.description;
        (0, federated_modules_1.default)(__assign(__assign({}, this.fedMod), { root: root })).apply(compiler);
        new extension_mapper_1.default(__assign(__assign({}, this.plugin), { name: this.plugin.name || (insights && insights.appname), version: this.plugin.version || version || '0.0.0', displayName: this.plugin.displayName || '', description: this.plugin.description || description || '', dependencies: __assign({}, (this.plugin.dependencies || {})), disableStaticPlugins: __spreadArray([], (this.plugin.disableStaticPlugins || []), true), extensions: __spreadArray([], (this.plugin.extensions || []), true) }), this.options).apply(compiler);
    };
    return ExtensionsPlugin;
}());
module.exports = ExtensionsPlugin;
//# sourceMappingURL=extensions-plugin.js.map