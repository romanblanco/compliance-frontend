declare const createPfReactTransform: (roots?: never[], moduleOverrides?: {
    [importName: string]: string;
}) => (string | {
    '@patternfly/react-core': {
        transform: (importName: string) => string;
        preventFullImport: boolean;
        skipDefaultConversion: boolean;
    };
    '@patternfly/react-icons': {
        transform: (importName: string) => string | undefined;
        preventFullImport: boolean;
    };
})[];
export default createPfReactTransform;
