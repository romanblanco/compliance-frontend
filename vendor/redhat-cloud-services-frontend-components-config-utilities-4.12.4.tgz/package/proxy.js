"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var child_process_1 = require("child_process");
var node_fetch_1 = __importDefault(require("node-fetch"));
var express_1 = __importDefault(require("express"));
var path_1 = __importDefault(require("path"));
var https_proxy_agent_1 = require("https-proxy-agent");
var chokidar_1 = __importDefault(require("chokidar"));
var cookieTransform_1 = __importDefault(require("./cookieTransform"));
var check_outgoing_requests_1 = require("./feo/check-outgoing-requests");
var crd_check_1 = require("./feo/crd-check");
var fec_logger_1 = __importStar(require("./fec-logger"));
var modify_response_1 = require("./feo/modify-response");
var defaultReposDir = path_1.default.join(__dirname, 'repos');
var checkLocalAppHost = function (appName, hostUrl, port) {
    var check = (0, child_process_1.execSync)("curl --max-time 5 --silent --head ".concat(hostUrl, " | awk '/^HTTP/{print $2}'")).toString().trim();
    if (check !== '200') {
        console.error('\n' + appName[0].toUpperCase() + appName.substring(1) + ' is not running or available via ' + hostUrl);
        console.log('\nMake sure to run `npm run start -- --port=' +
            port +
            '` in the ' +
            appName +
            " application directory to start it's webpack dev server and the bundle is built.\n");
        return false;
    }
    else {
        return true;
    }
};
var buildRoutes = function (routes, target) {
    return Object.entries(routes || {}).map(function (_a) {
        var route = _a[0], redirect = _a[1];
        var currTarget = typeof redirect === 'object' ? redirect.host : redirect;
        if (typeof redirect === 'object') {
            delete redirect.host;
        }
        var result = __assign({ context: function (path) { return path.includes(route); }, target: currTarget === 'PORTAL_BACKEND_MARKER' ? target : currTarget || undefined, secure: false, changeOrigin: true, autoRewrite: true, ws: true, onProxyReq: cookieTransform_1.default }, (typeof redirect === 'object' ? redirect : {}));
        return result;
    });
};
var buildLocalAppRoutes = function (localApps, defaultLocalAppHost, target) {
    return buildRoutes((!Array.isArray(localApps) ? localApps.split(',') : localApps).reduce(function (acc, curr) {
        var _a;
        var _b = (curr || '').split(':'), appName = _b[0], appConfig = _b[1];
        var _c = appConfig.split('~'), _d = _c[0], appPort = _d === void 0 ? 8003 : _d, _e = _c[1], protocol = _e === void 0 ? 'http' : _e;
        var appUrl = "".concat(protocol, "://").concat(defaultLocalAppHost, ":").concat(appPort);
        if (checkLocalAppHost(appName, appUrl, appPort)) {
            console.log('Creating app proxy routes for: ' + appName + ' to ' + appUrl);
            return __assign(__assign({}, acc), (_a = {}, _a["/apps/".concat(appName)] = {
                host: appUrl,
            }, _a));
        }
        else {
            process.exit();
        }
    }, {}), target);
};
var proxy = function (_a) {
    var _b = _a.env, env = _b === void 0 ? 'stage-stable' : _b, _c = _a.customProxy, customProxy = _c === void 0 ? [] : _c, routes = _a.routes, routesPath = _a.routesPath, useProxy = _a.useProxy, _d = _a.proxyURL, proxyURL = _d === void 0 ? 'http://squid.corp.redhat.com:3128' : _d, _e = _a.appUrl, appUrl = _e === void 0 ? [] : _e, publicPath = _a.publicPath, proxyVerbose = _a.proxyVerbose, _f = _a.useCloud, useCloud = _f === void 0 ? false : _f, _g = _a.target, target = _g === void 0 ? '' : _g, _h = _a.bounceProd, bounceProd = _h === void 0 ? false : _h, _j = _a.useAgent, useAgent = _j === void 0 ? true : _j, _k = _a.localApps, localApps = _k === void 0 ? process.env.LOCAL_APPS : _k, _l = _a.frontendCRDPath, frontendCRDPath = _l === void 0 ? path_1.default.resolve(process.cwd(), 'deploy/frontend.yaml') : _l;
    var frontendCrdRef = { current: undefined };
    var FEOFeaturesEnabled = false;
    try {
        frontendCrdRef.current = (0, crd_check_1.readFrontendCRD)(frontendCRDPath);
        FEOFeaturesEnabled = (0, crd_check_1.hasFEOFeaturesEnabled)(frontendCrdRef.current);
    }
    catch (e) {
        (0, fec_logger_1.default)(fec_logger_1.LogType.warn, "FEO features are not enabled. Unable to find frontend CRD file at ".concat(frontendCRDPath, ". If you want FEO features for local development, make sure to have a \"deploy/frontend.yaml\" file in your project or specify its location via \"frontendCRDPath\" attribute."));
    }
    var proxy = [];
    var majorEnv = env.split('-')[0];
    var defaultLocalAppHost = process.env.LOCAL_APP_HOST || majorEnv + '.foo.redhat.com';
    if (FEOFeaturesEnabled && (frontendCrdRef === null || frontendCrdRef === void 0 ? void 0 : frontendCrdRef.current)) {
        (0, fec_logger_1.default)(fec_logger_1.LogType.info, 'Watching frontend CRC file for changes');
        var watcher_1 = chokidar_1.default.watch(frontendCRDPath).on('change', function () {
            (0, fec_logger_1.default)(fec_logger_1.LogType.info, 'Frontend CRD has changed, reloading the file');
            try {
                frontendCrdRef.current = (0, crd_check_1.readFrontendCRD)(frontendCRDPath);
            }
            catch (error) {
                (0, fec_logger_1.default)(fec_logger_1.LogType.error, 'Error reloading frontend CRD file', error);
            }
        });
        process.on('SIGTERM', function () {
            (0, fec_logger_1.default)(fec_logger_1.LogType.info, 'Closing frontend CRD watcher');
            watcher_1.close();
        });
        process.on('SIGINT', function () {
            (0, fec_logger_1.default)(fec_logger_1.LogType.info, 'Closing frontend CRD watcher');
            watcher_1.close();
        });
    }
    if (target === '') {
        target += 'https://';
        if (!['prod', 'stage', 'dev'].includes(majorEnv)) {
            target += majorEnv + '.';
        }
        target += useCloud ? 'cloud' : 'console';
        if (['stage', 'dev'].includes(majorEnv)) {
            target += ".".concat(majorEnv);
        }
        target += '.redhat.com/';
    }
    var agent;
    var isProd = env.startsWith('prod');
    var isStage = env.startsWith('stage');
    var isEphemeral = env.startsWith('ephemeral');
    var shouldBounceProdRequests = isProd && bounceProd && !useAgent;
    if (isStage || isEphemeral || (isProd && useAgent)) {
        agent = new https_proxy_agent_1.HttpsProxyAgent(proxyURL);
    }
    if (isStage) {
        env = env.replace('stage', 'qa');
    }
    if (isEphemeral) {
        env = env.replace('ephemeral', 'qa');
    }
    if (!Array.isArray(appUrl)) {
        appUrl = [appUrl];
    }
    appUrl.push(publicPath);
    if (routesPath) {
        routes = require(routesPath);
    }
    if (routes) {
        routes = routes.routes || routes;
        proxy.push.apply(proxy, buildRoutes(routes, target));
    }
    if (localApps && localApps.length > 0) {
        proxy.push.apply(proxy, buildLocalAppRoutes(localApps, defaultLocalAppHost, target));
    }
    if (customProxy) {
        proxy.push.apply(proxy, customProxy);
    }
    if (useProxy) {
        proxy.push(__assign({ secure: false, changeOrigin: true, autoRewrite: true, onProxyRes: function (proxyRes, req, res) {
                if (FEOFeaturesEnabled && frontendCrdRef.current && (0, check_outgoing_requests_1.isInterceptAbleRequest)(req.url)) {
                    var _write_1 = res.write;
                    var body_1 = '';
                    proxyRes.on('data', function (chunk) {
                        body_1 += chunk;
                    });
                    res.write = function () {
                        try {
                            var payload = (0, modify_response_1.modifyRequest)(body_1, req.url, frontendCrdRef.current);
                            res.setHeader('content-length', payload.length);
                            _write_1.call(res, payload, 'utf8');
                            return true;
                        }
                        catch (_a) {
                            return true;
                        }
                    };
                }
            }, context: function (url) {
                var shouldProxy = !appUrl.find(function (u) { return (typeof u === 'string' ? url.startsWith(u) : u.test(url)); });
                if (shouldProxy) {
                    if (proxyVerbose) {
                        console.log('proxy', url);
                    }
                    return true;
                }
                return false;
            }, target: target, bypass: function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
                var result, text, data;
                var _a;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            if (!req.url.match(/\/api\//) && !req.url.match(/\./) && ((_a = req.headers.accept) === null || _a === void 0 ? void 0 : _a.includes('text/html'))) {
                                return [2, '/'];
                            }
                            if (!(shouldBounceProdRequests && req.method !== 'GET')) return [3, 3];
                            return [4, (0, node_fetch_1.default)((target + req.url).replace(/\/\//g, '/'), {
                                    method: req.method,
                                    body: JSON.stringify(req.body),
                                    headers: __assign(__assign({}, (req.headers.cookie && {
                                        cookie: req.headers.cookie,
                                    })), { 'Content-Type': 'application/json' }),
                                })];
                        case 1:
                            result = _b.sent();
                            return [4, result.text()];
                        case 2:
                            text = _b.sent();
                            try {
                                data = JSON.parse(text);
                                res.status(result.status).json(data);
                            }
                            catch (err) {
                                res.status(result.status).send(text);
                            }
                            _b.label = 3;
                        case 3: return [2, null];
                    }
                });
            }); } }, (agent
            ? {
                agent: agent,
                headers: {
                    'accept-encoding': 'gzip;q=0,deflate,sdch',
                    Host: target.replace('https://', ''),
                    Origin: target.replace(/\/$/, ''),
                },
            }
            : {
                'accept-encoding': 'gzip;q=0,deflate,sdch',
            })));
    }
    var config = __assign(__assign({}, (proxy.length > 0 && { proxy: proxy })), { onListening: function (server) {
            if (useProxy) {
                var host = useProxy ? "".concat(majorEnv === 'dev' ? 'prod' : majorEnv, ".foo.redhat.com") : 'localhost';
                var origin_1 = "https://".concat(host, ":").concat(server.options.port);
                console.log('App should run on:');
                console.log('\u001b[34m');
                if (appUrl.length > 0) {
                    appUrl.slice(0, appUrl.length - 1).forEach(function (url) { return console.log("  - ".concat(origin_1).concat(url)); });
                    console.log('\x1b[0m');
                    console.log('Static assets are available at:');
                    console.log('\u001b[34m');
                    console.log("  - ".concat(origin_1).concat(appUrl[appUrl.length - 1]));
                }
                else {
                    console.log("  - ".concat(origin_1));
                }
                console.log('\u001b[0m');
            }
        }, setupMiddlewares: function (middlewares, _a) {
            var app = _a.app, compiler = _a.compiler, options = _a.options;
            app === null || app === void 0 ? void 0 : app.enable('strict routing');
            if (shouldBounceProdRequests) {
                app === null || app === void 0 ? void 0 : app.use(express_1.default.json());
                app === null || app === void 0 ? void 0 : app.use(express_1.default.urlencoded({ extended: true }));
            }
            return middlewares;
        } });
    return config;
};
exports.default = proxy;
module.exports = proxy;
//# sourceMappingURL=proxy.js.map