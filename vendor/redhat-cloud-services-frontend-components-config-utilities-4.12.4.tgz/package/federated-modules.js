"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mergeSharedDeps = exports.applyImpliedDeps = exports.createSharedDeps = exports.bundleChromeSharedLocally = exports.createIncludes = void 0;
var path_1 = require("path");
var dynamic_plugin_sdk_webpack_1 = require("@openshift/dynamic-plugin-sdk-webpack");
var jsVarName_1 = __importDefault(require("./jsVarName"));
var fec_logger_1 = __importStar(require("./fec-logger"));
var resolve_shared_import_1 = require("./resolve-shared-import");
var defaultPluginMetaDataJSON = {
    version: '1.0.0',
    extensions: [],
};
var createIncludes = function () { return ({
    chromeProvided: {
        react: { singleton: true, eager: false, import: false },
        'react-dom': { singleton: true, eager: false, import: false },
        'react/jsx-runtime': { singleton: true, eager: false, import: false },
        'react/jsx-dev-runtime': { singleton: true, eager: false },
        'react-intl': { singleton: true, eager: false, import: false },
        'react-router-dom': { singleton: true, eager: false, import: false },
        '@openshift/dynamic-plugin-sdk': { singleton: true, eager: false, import: false },
        '@patternfly/quickstarts': { singleton: true, eager: false, import: false },
        '@redhat-cloud-services/chrome': { singleton: true, import: false },
        '@scalprum/core': { singleton: true, eager: false, import: false },
        '@scalprum/react-core': { singleton: true, eager: false, import: false },
        '@unleash/proxy-client-react': { singleton: true, eager: false, import: false },
    },
    defaultShared: {
        axios: {},
        lodash: {},
    },
    impliedDeps: {
        '@redhat-cloud-services/frontend-components': ['@scalprum/core', '@scalprum/react-core'],
    },
}); };
exports.createIncludes = createIncludes;
var bundleChromeSharedLocally = function (root, sharedModules) {
    if (sharedModules === void 0) { sharedModules = {}; }
    return Object.fromEntries(Object.entries(sharedModules).map(function (_a) {
        var moduleName = _a[0], config = _a[1];
        if (config.import !== false) {
            return [moduleName, config];
        }
        var importPath = (0, resolve_shared_import_1.resolveSharedImportPath)(root, moduleName);
        if (!importPath) {
            return [moduleName, config];
        }
        return [
            moduleName,
            __assign(__assign({}, config), { eager: true, import: importPath }),
        ];
    }));
};
exports.bundleChromeSharedLocally = bundleChromeSharedLocally;
var getRootPackage = function (key) {
    if (key.startsWith('@')) {
        return key.split('/').slice(0, 2).join('/');
    }
    return key.split('/')[0];
};
var createSharedDeps = function (include, dependencies, exclude) {
    return Object.entries(include)
        .filter(function (_a) {
        var key = _a[0];
        return dependencies[getRootPackage(key)] && !exclude.includes(key);
    })
        .map(function (_a) {
        var _b;
        var key = _a[0], val = _a[1];
        return (_b = {},
            _b[key] = __assign({ requiredVersion: dependencies[getRootPackage(key)] }, val),
            _b);
    })
        .reduce(function (acc, curr) { return (__assign(__assign({}, acc), curr)); }, {});
};
exports.createSharedDeps = createSharedDeps;
var applyImpliedDeps = function (sharedDeps, include, dependencies, impliedDeps) {
    var result = __assign({}, sharedDeps);
    for (var _i = 0, _a = Object.entries(impliedDeps); _i < _a.length; _i++) {
        var _b = _a[_i], trigger = _b[0], targets = _b[1];
        if (dependencies[trigger]) {
            for (var _c = 0, targets_1 = targets; _c < targets_1.length; _c++) {
                var target = targets_1[_c];
                if (!result[target] && include[target]) {
                    result[target] = __assign({ requiredVersion: '*' }, include[target]);
                }
            }
        }
    }
    return result;
};
exports.applyImpliedDeps = applyImpliedDeps;
var mergeSharedDeps = function (sharedDeps, shared, chromeProvided, logger) {
    if (logger === void 0) { logger = fec_logger_1.default; }
    return shared.reduce(function (acc, dep) {
        var tenantOnly = Object.fromEntries(Object.entries(dep).filter(function (_a) {
            var key = _a[0];
            if (chromeProvided[key]) {
                logger(fec_logger_1.LogType.warn, "\"".concat(key, "\" is provided by insights-chrome and cannot be configured via shared[]. Entry ignored."));
                return false;
            }
            return true;
        }));
        if (!hasVersionSpecified(tenantOnly)) {
            var invalidDeps = Object.entries(tenantOnly)
                .filter(function (_a) {
                var version = _a[1].version;
                return typeof version !== 'string';
            })
                .map(function (_a) {
                var moduleName = _a[0];
                return moduleName;
            });
            throw new Error('Some of your shared dependencies do not have version specified! Dependencies with no version: ' + invalidDeps);
        }
        return __assign(__assign({}, acc), tenantOnly);
    }, sharedDeps);
};
exports.mergeSharedDeps = mergeSharedDeps;
function hasVersionSpecified(config) {
    return Object.values(config).every(function (c) { return typeof c.version === 'string'; });
}
var federatedModules = function (_a) {
    var root = _a.root, depsProp = _a.dependencies, exposes = _a.exposes, _b = _a.shared, shared = _b === void 0 ? [] : _b, debug = _a.debug, moduleName = _a.moduleName, _c = _a.useFileHash, useFileHash = _c === void 0 ? true : _c, _d = _a.separateRuntime, separateRuntime = _d === void 0 ? false : _d, _e = _a.exclude, exclude = _e === void 0 ? [] : _e, _f = _a.bundleChromeShared, bundleChromeShared = _f === void 0 ? false : _f, _g = _a.eager, eager = _g === void 0 ? false : _g, pluginMetadata = _a.pluginMetadata, _h = _a.extensions, extensions = _h === void 0 ? [] : _h;
    var _j = (0, exports.createIncludes)(), chromeProvided = _j.chromeProvided, defaultShared = _j.defaultShared, impliedDeps = _j.impliedDeps;
    var include = __assign(__assign({}, chromeProvided), defaultShared);
    var _k = depsProp ? { dependencies: depsProp, insights: undefined } : require((0, path_1.resolve)(root, './package.json')) || {}, _l = _k.dependencies, dependencies = _l === void 0 ? {} : _l, insights = _k.insights;
    var appName = moduleName || (insights && (0, jsVarName_1.default)(insights.appname));
    var filename = "".concat(appName, ".").concat(useFileHash ? "[contenthash]." : '', "js");
    var sharedDeps = __assign(__assign({}, (0, exports.createSharedDeps)(chromeProvided, dependencies, [])), (0, exports.createSharedDeps)(defaultShared, dependencies, exclude));
    sharedDeps = (0, exports.applyImpliedDeps)(sharedDeps, include, dependencies, impliedDeps);
    sharedDeps = (0, exports.mergeSharedDeps)(sharedDeps, shared, chromeProvided);
    if (bundleChromeShared || eager) {
        sharedDeps = (0, exports.bundleChromeSharedLocally)(root, sharedDeps);
    }
    if (debug) {
        console.log('Using package at path: ', (0, path_1.resolve)(root, './package.json'));
        console.log('Using appName: ', appName);
        console.log("Using ".concat(exposes ? 'custom' : 'default', " exposes"));
        console.log('Number of custom shared modules is: ', shared.length);
        console.log('Number of merged shared modules is: ', Object.keys(sharedDeps).length);
        if (exclude.length > 0) {
            console.log('Excluding default packages', exclude);
        }
        if (bundleChromeShared || eager) {
            console.log('Bundling chrome-provided shared modules from local node_modules');
        }
    }
    if (!exposes) {
        (0, fec_logger_1.default)(fec_logger_1.LogType.warn, 'No exposed modules provided! Falling back to ./src/AppEntry as "./RootApp"');
    }
    var pluginMetadataInternal = __assign(__assign(__assign(__assign({}, defaultPluginMetaDataJSON), { name: appName }), pluginMetadata), { exposedModules: __assign({}, (exposes || {
            './RootApp': "./".concat((0, path_1.relative)(root, './src/AppEntry')),
        })) });
    var dynamicPlugin = new dynamic_plugin_sdk_webpack_1.DynamicRemotePlugin({
        extensions: extensions,
        sharedModules: sharedDeps,
        entryScriptFilename: filename,
        moduleFederationSettings: {
            libraryType: separateRuntime ? 'var' : 'jsonp',
        },
        pluginManifestFilename: 'fed-mods.json',
        pluginMetadata: pluginMetadataInternal,
    });
    return dynamicPlugin;
};
exports.default = federatedModules;
//# sourceMappingURL=federated-modules.js.map